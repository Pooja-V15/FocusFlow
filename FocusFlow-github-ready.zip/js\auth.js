document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("[data-auth-form]");
  const password = document.querySelector("[data-password]");
  const meter = document.querySelector("[data-password-meter]");

  password?.addEventListener("input", () => {
    const value = password.value;
    let score = 0;
    if (value.length >= 8) score += 30;
    if (/[A-Z]/.test(value)) score += 25;
    if (/[0-9]/.test(value)) score += 20;
    if (/[^A-Za-z0-9]/.test(value)) score += 25;
    if (meter) meter.style.width = `${Math.min(score, 100)}%`;
  });

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    const mode = form.dataset.authForm;
    const payload = Object.fromEntries(new FormData(form));
    try {
      const endpoint = mode === "register" ? "/auth/register" : "/auth/login";
      const data = await apiRequest(endpoint, { method: "POST", body: JSON.stringify(payload) });
      localStorage.setItem("focusflow_token", data.token);
      localStorage.setItem("focusflow_user", JSON.stringify(data.user));
      toast(mode === "register" ? "Account created. Welcome to FocusFlow." : "Signed in successfully.");
      setTimeout(() => { window.location.href = "dashboard.html"; }, 700);
    } catch (error) {
      localStorage.setItem("focusflow_user", JSON.stringify({ name: payload.name || "Alex Morgan" }));
      toast("Demo mode opened because the API is offline.", "info");
      setTimeout(() => { window.location.href = "dashboard.html"; }, 700);
    }
  });
});
